exec /usr/local/bsc/flowdetect/flowdetect  -kafka-brokers "bgp-beijing-beijing-1-123-59-102-47:6667"
